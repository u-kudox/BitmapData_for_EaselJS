YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "createjs.BitmapData",
        "createjs.BitmapDataChannel",
        "createjs.ColorTransform"
    ],
    "modules": [],
    "allModules": []
} };
});